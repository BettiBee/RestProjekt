package suli.project.webservice.restful.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name = "tasks")
public class Task implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int taskID;
	private String taskTitle;
	private Date taskDate;
	private String taskRepeat;
	private String goal;
	private int goalID;
	private List<Link> links = new ArrayList<>();
	
	public Task(){}

	@XmlElement
	public int getTaskID() {
		return taskID;
	}
	
	public Task(int taskID, String taskTitle, Date taskDate, String taskRepeat, String goal, int goalID) {
		super();
		this.taskID = taskID;
		this.taskTitle = taskTitle;
		this.taskDate = taskDate;
		this.taskRepeat = taskRepeat;
		this.goal = goal;
		this.goalID = goalID;
	}

	public String getTaskTitle() {
		return taskTitle;
	}

	public void setTaskTitle(String taskTitle) {
		this.taskTitle = taskTitle;
	}

	public Date getTaskDate() {
		return taskDate;
	}

	public void setTaskDate(Date taskDate) {
		this.taskDate = taskDate;
	}

	public String getTaskRepeat() {
		return taskRepeat;
	}

	public void setTaskRepeat(String taskRepeat) {
		this.taskRepeat = taskRepeat;
	}

	public String getGoal() {
		return goal;
	}

	public void setGoal(String goal) {
		this.goal = goal;
	}

	public int getGoalID() {
		return goalID;
	}

	public void setGoalID(int goalID) {
		this.goalID = goalID;
	}

	public List<Link> getLinks() {
		return links;
	}

	public void setLinks(List<Link> links) {
		this.links = links;
	}

	public void setTaskID(int taskID) {
		this.taskID = taskID;
	}

	public void addLink(String url, String rel){
		Link newlink = new Link();
		newlink.setLink(url);
		newlink.setRel(rel);
		links.add(newlink);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((goal == null) ? 0 : goal.hashCode());
		result = prime * result + goalID;
		result = prime * result + ((links == null) ? 0 : links.hashCode());
		result = prime * result + ((taskDate == null) ? 0 : taskDate.hashCode());
		result = prime * result + taskID;
		result = prime * result + ((taskRepeat == null) ? 0 : taskRepeat.hashCode());
		result = prime * result + ((taskTitle == null) ? 0 : taskTitle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Task other = (Task) obj;
		if (goal == null) {
			if (other.goal != null)
				return false;
		} else if (!goal.equals(other.goal))
			return false;
		if (goalID != other.goalID)
			return false;
		if (links == null) {
			if (other.links != null)
				return false;
		} else if (!links.equals(other.links))
			return false;
		if (taskDate == null) {
			if (other.taskDate != null)
				return false;
		} else if (!taskDate.equals(other.taskDate))
			return false;
		if (taskID != other.taskID)
			return false;
		if (taskRepeat == null) {
			if (other.taskRepeat != null)
				return false;
		} else if (!taskRepeat.equals(other.taskRepeat))
			return false;
		if (taskTitle == null) {
			if (other.taskTitle != null)
				return false;
		} else if (!taskTitle.equals(other.taskTitle))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Task [taskID=" + taskID + ", taskTitle=" + taskTitle + ", taskDate=" + taskDate + ", taskRepeat="
				+ taskRepeat + ", goal=" + goal + ", goalID=" + goalID + ", links=" + links + "]";
	}
	
	
}
