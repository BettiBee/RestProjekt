package suli.project.webservice.restful.database;

import java.sql.Connection;
import suli.project.webservice.restful.database.ConnectionInfo;
import suli.project.webservice.restful.model.Goal;
import suli.project.webservice.restful.model.User;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserQuery {
	
	public static Connection getConnection() throws Exception {
	    String driver = ConnectionInfo.getClassVar();
	    String url = ConnectionInfo.getDb();
	    String user = ConnectionInfo.getUser();
	    String password = ConnectionInfo.getPass();
	    Class.forName(driver);
	    Connection conn = DriverManager.getConnection(url, user, password);
	    return conn;
	  }

	public List<User> selectAll(Connection conn) throws ClassNotFoundException, SQLException{
		
		String query = "select *from users";
		List<User> response=new ArrayList<>();
		
		try{
		Statement stmt=conn.createStatement();  
		ResultSet rs=stmt.executeQuery(query);
		//ResultSetMetaData rsmd = rs.getMetaData();
		
		while (rs.next()) {
		   User model = new User();
		   model.setUserID(rs.getInt(1));
		   model.setUserName(rs.getString(2));
		   model.setUserEmail(rs.getString(3));
		   response.add(model);
		}
		
		conn.close();  
			
		}catch(Exception e){ 
			System.out.println(e);
		}  
		
		System.out.println(response);
		return response;
	}
	
	public User getOneUser(Connection conn, int userID){
		String query = "select * from users where userID = " + "'" + userID + "';";
		User model = new User();
		
		try{
			Statement stmt=conn.createStatement();  
			ResultSet rs=stmt.executeQuery(query);
			
			while (rs.next()) {
			   
			   model.setUserID(rs.getInt(1));
			   model.setUserName(rs.getString(2));
			   model.setUserEmail(rs.getString(3));
			}
			
			conn.close();  
				
			}catch(Exception e){ 
				System.out.println(e);
			}  
		
			return model;
		}
	
		public void addModel(Connection conn, User model) throws ClassNotFoundException, SQLException{
		
		try
	    {
	         
	      String query = " insert into users (userID, userName, userEmail)"
	        + " values (?, ?, ?)";

	      PreparedStatement preparedStmt = conn.prepareStatement(query);
	      preparedStmt.setInt(1, model.getUserID());
	      preparedStmt.setString(2, model.getUserName());
	      preparedStmt.setString(3, model.getUserEmail());
	     
	      // execute the preparedstatement
	      preparedStmt.execute();
	      conn.close();
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception!");
	      System.err.println(e.getMessage());
	    }
	}
		
		public void updateModel(Connection conn, User user, int userID) throws SQLException{
		//User updatedUser = new User();
		
		try
		  {
		    PreparedStatement ps = conn.prepareStatement(
		      "UPDATE users SET userName = ? , userEmail = ? WHERE userID =" + userID + ";");

		    ps.setString(1, user.getUserName());
		    ps.setString(2, user.getUserEmail());
		    

		    ps.executeUpdate();
		    ps.close();
		  }
		  catch (SQLException se)
		  {
			  System.err.println("Got an exception!");
		      System.err.println(se.getMessage());
		  }
	}
	
	public void deleteModel(Connection conn, int userID) throws SQLException{
		List<Goal> goals = new ArrayList<>();
		String getGoals = "select goalID from goals where userID =" + userID + ";";
		
		Statement stmt=conn.createStatement();  
		ResultSet rs=stmt.executeQuery(getGoals);
		//ResultSetMetaData rsmd = rs.getMetaData();
		
		while (rs.next()) {
		   Goal model = new Goal();
		   model.setGoalID(rs.getInt(1));
		   goals.add(model);
		}
		
		
		PreparedStatement preState;
		
		String query = "DELETE FROM users WHERE userID = " + userID + ";";
		preState = conn.prepareStatement(query);
		
		String goalquery = "DELETE FROM goals WHERE userID = " + userID + ";";
		preState = conn.prepareStatement(goalquery);
		
		for(int i=0; i<=goals.size(); ++i){
			String taskquery = "DELETE FROM tasks WHERE goalID = " + goals.get(i) + ";";
			preState = conn.prepareStatement(taskquery);
		}	
		
		preState.execute();
		conn.close();  
	}
}
