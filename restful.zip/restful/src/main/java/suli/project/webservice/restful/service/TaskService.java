package suli.project.webservice.restful.service;

import java.sql.SQLException;
import java.util.List;

import suli.project.webservice.restful.database.TaskQuery;
import suli.project.webservice.restful.model.Task;

public class TaskService {
	
	private TaskQuery query = new TaskQuery();
	
	public List<Task> getTasks(int goalID) throws ClassNotFoundException, SQLException, Exception{
		List<Task> tasks = query.selectAll(TaskQuery.getConnection(), goalID);
		return tasks;
	}
	
	public Task getOneTask(int taskID) throws Exception{
		Task task = query.getOneTask(TaskQuery.getConnection(), taskID);
		return task;
	}
	
	public void addTask(Task newtask) throws ClassNotFoundException, SQLException, Exception{
		query.addModel(TaskQuery.getConnection(), newtask);
	}
	
	public void updateTask(Task task, int taskID) throws SQLException, Exception{
			query.updateModel(TaskQuery.getConnection(), task, taskID);
	}
	
	public void deleteTask(int taskID) throws SQLException, Exception{
		query.deleteModel(TaskQuery.getConnection(), taskID);
	}

}
