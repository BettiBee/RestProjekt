package suli.project.webservice.restful.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import suli.project.webservice.restful.model.Goal;

public class GoalQuery {

	public static Connection getConnection() throws Exception {
	    String driver = ConnectionInfo.getClassVar();
	    String url = ConnectionInfo.getDb();
	    String user = ConnectionInfo.getUser();
	    String password = ConnectionInfo.getPass();
	    Class.forName(driver);
	    Connection conn = DriverManager.getConnection(url, user, password);
	    return conn;
	  }
	
	public List<Goal> selectAll(Connection conn, int userID) throws ClassNotFoundException, SQLException{
		
		String query = "select * from goals where userID = " + userID;
		List<Goal> response=new ArrayList<>();
		
		try{
		Statement stmt=conn.createStatement();  
		ResultSet rs=stmt.executeQuery(query);
		//ResultSetMetaData rsmd = rs.getMetaData();
		
		while (rs.next()) {
		   Goal model = new Goal();
		   model.setGoalID(rs.getInt(1));
		   model.setGoalTitle(rs.getString(2));
		   model.setGoalDate(rs.getDate(3));
		   model.setGoalStatus(rs.getString(4));
		   model.setUser(rs.getString(5));
		   model.setUserID(6);
		   response.add(model);
		   System.out.println(response);
		}
		
		conn.close();  
			
		}catch(Exception e){ 
			System.out.println(e);
		}  
		
		System.out.println(response);
		return response;
	}
	
	public Goal getOneGoal(Connection conn, int goalID){ //ide lehet kell majd userID is...
		String query = "select * from goals where goalID = " + goalID;  // and userID = userID
		Goal model = new Goal();
		
		try{
			Statement stmt=conn.createStatement();  
			ResultSet rs=stmt.executeQuery(query);
			
			while (rs.next()) {
				model.setGoalID(rs.getInt(1));
				model.setGoalTitle(rs.getString(2));
				model.setGoalDate(rs.getDate(3));
				model.setGoalStatus(rs.getString(4));
				model.setUser(rs.getString(5));
				model.setUserID(6);
			}
			
			conn.close();  
				
			}catch(Exception e){ 
				System.out.println(e);
			}  
		
			return model;
		}
	
	public void addModel(Connection conn, Goal model) throws ClassNotFoundException, SQLException{
		
		try
	    {
	         
	      String query = " insert into goals (goalID, goalTitle, goalDate, goalStatus, user, userID)"
	        + " values (?, ?, ?, ?, ?, ?)";

	      PreparedStatement preparedStmt = conn.prepareStatement(query);
	      preparedStmt.setInt(1, model.getGoalID());
	      preparedStmt.setString(2, model.getGoalTitle());
	      preparedStmt.setDate(3, model.getGoalDate());
	      preparedStmt.setString(4, model.getGoalStatus());
	      preparedStmt.setString(5, model.getUser());
	      preparedStmt.setInt(6, model.getUserID());
	     
	      // execute the preparedstatement
	      preparedStmt.execute();
	      conn.close();
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception!");
	      System.err.println(e.getMessage());
	    }
	}
	
	public void updateModel(Connection conn, Goal goal, int goalID) throws SQLException{
		//Goal updatedGoal = new Goal();
		
		try
		  {
		    PreparedStatement ps = conn.prepareStatement(
		      "UPDATE goals SET goalTitle = ? , goalDate = ?, goalStatus = ? WHERE goalID =" + goalID + ";");

		    ps.setString(1, goal.getGoalTitle());
		    ps.setDate(2, goal.getGoalDate());
		    ps.setString(3, goal.getGoalStatus());
		    

		    ps.executeUpdate();
		    ps.close();
		  }
		  catch (SQLException se)
		  {
			  System.err.println("Got an exception!");
		      System.err.println(se.getMessage());
		  }
	}
	
	public void deleteModel(Connection conn, int goalID) throws SQLException{
		
		String query = "DELETE FROM goals WHERE goalID = " + goalID + ";";
		PreparedStatement preState = conn.prepareStatement(query);
		String taskquery = "DELETE FROM tasks WHERE goalID =" + goalID + ";";
		preState = conn.prepareStatement(taskquery);
		preState.execute();
		conn.close();  
	}
	
}
