package suli.project.webservice.restful.service;

import java.sql.SQLException;
import java.util.List;

import suli.project.webservice.restful.database.GoalQuery;
import suli.project.webservice.restful.model.Goal;

public class GoalService {
	
	public GoalService(){}
	
	private GoalQuery query = new GoalQuery();
	
	public List<Goal> getGoals(int userID) throws ClassNotFoundException, SQLException, Exception{
		List<Goal> goals = query.selectAll(GoalQuery.getConnection(), userID);
		return goals;
	}
	
	public Goal getOneGoal(int goalID) throws Exception{
		Goal goal = query.getOneGoal(GoalQuery.getConnection(), goalID);
		return goal;
	}
	
	public void addGoal(Goal newgoal) throws ClassNotFoundException, SQLException, Exception{
		query.addModel(GoalQuery.getConnection(), newgoal);
	}
	
	public void updateGoal(Goal goal, int goalID) throws SQLException, Exception{
		query.updateModel(GoalQuery.getConnection(), goal, goalID);
	}
	
	public void deleteGoal(int goalID) throws SQLException, Exception{
		query.deleteModel(GoalQuery.getConnection(), goalID);
	}

}
