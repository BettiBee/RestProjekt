package suli.project.webservice.restful.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name = "goals")
public class Goal implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int goalID;
	private String goalTitle;
	private Date goalDate;
	private String goalStatus;
	private String user;
	private int userID;
	private List<Link> links = new ArrayList<>();
	
	public Goal(){}

	public Goal(int goalID, String goalTitle, Date goalDate, String goalStatus, String user, int userID) {
		super();
		this.goalID = goalID;
		this.goalTitle = goalTitle;
		this.goalDate = goalDate;
		this.goalStatus = goalStatus;
		this.user = user;
		this.userID = userID;
	}
	
	@XmlElement
	public int getGoalID() {
		return goalID;
	}

	public void setGoalID(int goalID) {
		this.goalID = goalID;
	}

	public String getGoalTitle() {
		return goalTitle;
	}

	public void setGoalTitle(String goalTitle) {
		this.goalTitle = goalTitle;
	}

	public Date getGoalDate() {
		return goalDate;
	}

	public void setGoalDate(Date goalDate) {
		this.goalDate = goalDate;
	}

	public String getGoalStatus() {
		return goalStatus;
	}

	public void setGoalStatus(String goalStatus) {
		this.goalStatus = goalStatus;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public List<Link> getLinks() {
		return links;
	}

	public void setLinks(List<Link> links) {
		this.links = links;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public void addLink(String url, String rel){
		Link newlink = new Link();
		newlink.setLink(url);
		newlink.setRel(rel);
		links.add(newlink);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((goalDate == null) ? 0 : goalDate.hashCode());
		result = prime * result + goalID;
		result = prime * result + ((goalStatus == null) ? 0 : goalStatus.hashCode());
		result = prime * result + ((goalTitle == null) ? 0 : goalTitle.hashCode());
		result = prime * result + ((links == null) ? 0 : links.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		result = prime * result + userID;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Goal other = (Goal) obj;
		if (goalDate == null) {
			if (other.goalDate != null)
				return false;
		} else if (!goalDate.equals(other.goalDate))
			return false;
		if (goalID != other.goalID)
			return false;
		if (goalStatus == null) {
			if (other.goalStatus != null)
				return false;
		} else if (!goalStatus.equals(other.goalStatus))
			return false;
		if (goalTitle == null) {
			if (other.goalTitle != null)
				return false;
		} else if (!goalTitle.equals(other.goalTitle))
			return false;
		if (links == null) {
			if (other.links != null)
				return false;
		} else if (!links.equals(other.links))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		if (userID != other.userID)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Goal [goalID=" + goalID + ", goalTitle=" + goalTitle + ", goalDate=" + goalDate + ", goalStatus="
				+ goalStatus + ", user=" + user + ", userID=" + userID + ", links=" + links + "]";
	}

	
}
