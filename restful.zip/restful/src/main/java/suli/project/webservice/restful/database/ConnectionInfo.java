package suli.project.webservice.restful.database;

public class ConnectionInfo {
	
	private static String db = "jdbc:mysql://localhost:3306/restdb";
	private static String user = "root";
	private static String pass = "root12";
	private static String classVar= "com.mysql.jdbc.Driver";
	
	public static String getDb() {
		return db;
	}
	public static String getUser() {
		return user;
	}
	public static String getPass() {
		return pass;
	}
	public static String getClassVar() {
		return classVar;
	}

}
