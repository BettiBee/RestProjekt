package suli.project.webservice.restful.annotated;

import java.net.URI;
import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import suli.project.webservice.restful.model.User;
import suli.project.webservice.restful.service.UserService;

@Path("/users")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class UserResource {
	
	private UserService service = new UserService();
	
	@GET
	public List<User> getUsers() throws ClassNotFoundException, SQLException, Exception{
		List<User> users = service.getUsers();
		return users;
	}
	
	@GET
	@Path("/{userID}")
	public User getOneUser(@PathParam("userID") int userID, @Context UriInfo urinfo) throws Exception{
		User user = service.getOneUser(userID);
		user.addLink(selfURI(urinfo, user), "self");
		user.addLink(goalURI(urinfo, user),"goals");
		return user;
	}

	@POST
	@Path("/users")
	public void addUser(User newuser) throws ClassNotFoundException, SQLException, Exception{
		service.addUser(newuser);
	}
	
	@PUT
	@Path("/{userID}")
	public void updateUser(User updatedUser, @PathParam("userID") int userID) throws SQLException, Exception{
		service.updateGoal(updatedUser, userID);
	}
	
	@DELETE
	@Path("/{userID}")
	public void deleteUser(@PathParam("userID") int userID) throws SQLException, Exception{
		service.deleteUser(userID);
	}
	
	@Path("/{userID}/goals")
	public GoalResource getGoalResource(){
		return new GoalResource();
	}
	
	private String selfURI(UriInfo urinfo, User user) {
		String uri = urinfo.getBaseUriBuilder()
				.path(UserResource.class)
				.path(Integer.toString(user.getUserID()))
				.build()
				.toString();
		return uri;
	}
	
	private String goalURI(UriInfo urinfo, User user) {
		URI uri = urinfo.getBaseUriBuilder() //.../webapi/
				.path(UserResource.class) //   /users
				.path(UserResource.class, "getGoalResource") //   /{userID}/goals
				.resolveTemplate("userID", user.getUserID()) //   /userID/goals
				.build();
		return uri.toString();
	}
	
}
