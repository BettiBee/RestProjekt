package suli.project.webservice.restful.service;

import java.sql.SQLException;
import java.util.List;

import suli.project.webservice.restful.database.UserQuery;
import suli.project.webservice.restful.model.User;

public class UserService {
	
	private UserQuery query = new UserQuery();
	
	public List<User> getUsers() throws ClassNotFoundException, SQLException, Exception{
		List<User> users = query.selectAll(UserQuery.getConnection());
		return users;
	}
	
	public User getOneUser(int userID) throws Exception{
		User user = query.getOneUser(UserQuery.getConnection(), userID);
		return user;
	}
	
	
	public void addUser(User newUser) throws ClassNotFoundException, SQLException, Exception{
		query.addModel(UserQuery.getConnection(), newUser);
	}
	
	public void updateGoal(User updatedUser, int userID) throws SQLException, Exception {
		query.updateModel(UserQuery.getConnection(), updatedUser, userID);
		
	}
	
	public void deleteUser(int userID) throws SQLException, Exception{
		query.deleteModel(UserQuery.getConnection(), userID);
	}

	

}
