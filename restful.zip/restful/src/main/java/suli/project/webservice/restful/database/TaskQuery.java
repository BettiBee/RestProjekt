package suli.project.webservice.restful.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import suli.project.webservice.restful.database.ConnectionInfo;
import suli.project.webservice.restful.model.Task;

public class TaskQuery {
	
	public static Connection getConnection() throws Exception {
	    String driver = ConnectionInfo.getClassVar();
	    String url = ConnectionInfo.getDb();
	    String user = ConnectionInfo.getUser();
	    String password = ConnectionInfo.getPass();
	    Class.forName(driver);
	    Connection conn = DriverManager.getConnection(url, user, password);
	    return conn;
	  }
	
	public List<Task> selectAll(Connection conn, int goalID) throws ClassNotFoundException, SQLException{
		
		String query = "select * from tasks where goalID =" + goalID;
		List<Task> response=new ArrayList<>();
		
		try{
		Statement stmt=conn.createStatement();  
		ResultSet rs=stmt.executeQuery(query);
		//ResultSetMetaData rsmd = rs.getMetaData();
		
		while (rs.next()) {
		   Task model = new Task();
		   model.setTaskID(rs.getInt(1));
		   model.setTaskTitle(rs.getString(2));
		   model.setTaskDate(rs.getDate(3));
		   model.setTaskRepeat(rs.getString(4));
		   model.setGoal(rs.getString(5));
		   model.setGoalID(rs.getInt(6));
		   response.add(model);
		}
		
		conn.close();  
			
		}catch(Exception e){ 
			System.out.println(e);
		}  
		
		System.out.println(response);
		return response;
	}
	
	public Task getOneTask(Connection conn, int taskID){ //lehet ide is kell majd a goalID
		String query = "select * from tasks where taskID = " + taskID + ";"; // and goalID = goalID
		Task model = new Task();
		//List<Task> task = new ArrayList<>();
		try{
			Statement stmt=conn.createStatement();  
			ResultSet rs=stmt.executeQuery(query);
			
			while (rs.next()) {
			   //Task model = new Task();
			   model.setTaskID(rs.getInt(1));
			   model.setTaskTitle(rs.getString(2));
			   model.setTaskDate(rs.getDate(3));
			   model.setTaskRepeat(rs.getString(4));
			   model.setGoal(rs.getString(5));
			  // task.add(model);
			}
			
			conn.close();  
				
			}catch(Exception e){ 
				System.out.println(e);
			}  
		
			return model;
		}
	
	public void addModel(Connection conn, Task model) throws ClassNotFoundException, SQLException{
		
		try
	    {
	         
	      String query = " insert into tasks (taskID, taskTitle, taskDate, taskRepeat, goal, goalID)"
	        + " values (?, ?, ?, ?, ?, ?)";

	      PreparedStatement preparedStmt = conn.prepareStatement(query);
	      preparedStmt.setInt(1, model.getTaskID());
	      preparedStmt.setString(2, model.getTaskTitle());
	      preparedStmt.setDate(3, model.getTaskDate());
	      preparedStmt.setString(4, model.getTaskRepeat());
	      preparedStmt.setString(5, model.getGoal());
	      preparedStmt.setInt(6, model.getGoalID());
	     
	      // execute the preparedstatement
	      preparedStmt.execute();
	      conn.close();
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception!");
	      System.err.println(e.getMessage());
	    }
	}
	
	public void updateModel(Connection conn, Task task, int taskID) throws SQLException{
		//Task updatedTask = new Task();
		
		try
		  {
		    PreparedStatement ps = conn.prepareStatement(
		      "UPDATE tasks SET taskTitle = ? , taskDate = ?, taskRepeat = ? WHERE taskID = " + taskID + ";");

		    ps.setString(1, task.getTaskTitle());
		    ps.setDate(2, task.getTaskDate());
		    ps.setString(3, task.getTaskRepeat());
		  
		    ps.executeUpdate();
		    ps.close();
		  }
		  catch (SQLException se)
		  {
			  System.err.println("Got an exception!");
		      System.err.println(se.getMessage());
		  }
	}
	
	public void deleteModel(Connection conn, int taskID) throws SQLException{
		
		String query = "DELETE FROM tasks WHERE taskID = " + taskID + ";";
		PreparedStatement preState = conn.prepareStatement(query);
		preState.execute();
		conn.close();  
	}
	

}
