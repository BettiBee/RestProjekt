package suli.project.webservice.restful.annotated;

import java.net.URI;
import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import suli.project.webservice.restful.model.Goal;
import suli.project.webservice.restful.service.GoalService;

@Path("/goals")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class GoalResource {
	
	private GoalService service = new GoalService();
	
	@GET
	public List<Goal> getGoals(@PathParam("userID") int userID) throws ClassNotFoundException, SQLException, Exception{
		return service.getGoals(userID);
	}
	
	@GET
	@Path("/{goalID}")
	public Goal getOneGoal(@PathParam("goalID") int goalID, @Context UriInfo urinfo) throws Exception{
		Goal goal = service.getOneGoal(goalID);
		goal.addLink(selfURI(urinfo, goal), "self");
		goal.addLink(userURI(urinfo, goal), "user");
		goal.addLink(tasksURI(urinfo, goal), "tasks");
		return goal;
	}
	
	@POST
	@Path("/goals")
	public void addGoal(Goal newgoal) throws ClassNotFoundException, SQLException, Exception{
		service.addGoal(newgoal);
	}
	
	@PUT
	@Path("/{goalID}")
	public void updateGoal(Goal updatedGoal, @PathParam("goalID") int goalID) throws SQLException, Exception{
		service.updateGoal(updatedGoal, goalID);
	}

	@DELETE
	@Path("/{goalID}")
	public void deleteGoal(@PathParam("goalID") int goalID) throws SQLException, Exception{
		service.deleteGoal(goalID);
	}
	

	@Path("/{goalID}/tasks")
	public TaskResource getTaskResource(){
		return new TaskResource();
	}
	
	private String selfURI(UriInfo urinfo, Goal goal) {
		URI uri = urinfo.getBaseUriBuilder()
				.path(GoalResource.class)
				.path(Integer.toString(goal.getGoalID()))
				.build();
		return uri.toString();
	}
	
	private String tasksURI(UriInfo urinfo, Goal goal) {
		URI uri = urinfo.getBaseUriBuilder()
				.path(GoalResource.class)
				.path(GoalResource.class, "getTaskResource")
				.resolveTemplate("goalID", goal.getGoalID())
				.build();
		return uri.toString();
	}
	
	private String userURI(UriInfo urinfo, Goal goal) {
		URI uri = urinfo.getBaseUriBuilder()
				.path(UserResource.class)
				.path(Integer.toString(goal.getUserID()))
				.build();
		return uri.toString();
	}

}
