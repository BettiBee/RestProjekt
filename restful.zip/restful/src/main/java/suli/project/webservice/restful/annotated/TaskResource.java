package suli.project.webservice.restful.annotated;

import java.net.URI;
import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import suli.project.webservice.restful.model.Task;
import suli.project.webservice.restful.service.TaskService;

@Path("/tasks")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class TaskResource {
	
	private TaskService service = new TaskService();
	
	@GET
	@Path("/tasks")
	public List<Task> getTasks(@PathParam("goalID") int goalID) throws ClassNotFoundException, SQLException, Exception{
		return service.getTasks(goalID);
	}
	
	@GET
	@Path("/{taskID}")
	public Task getOneTask(@PathParam("taskID") int taskID, @Context UriInfo urinfo) throws Exception{
		Task task = service.getOneTask(taskID);
		task.addLink(selfURI(urinfo, task), "self");
		task.addLink(goalURI(urinfo, task), "goal");
		return task;
	}
	
	@POST
	@Path("/tasks")
	public void addTask(Task newtask) throws ClassNotFoundException, SQLException, Exception{
		service.addTask(newtask);
	}
	
	@PUT
	@Path("/{taskID}")
	public void updateTask(Task updatedTask, @PathParam("taskID") int taskID) throws SQLException, Exception{
		service.updateTask(updatedTask, taskID);
	}
	
	@DELETE
	@Path("/{taskID}")
	public void deleteTask(@PathParam("taskID") int taskID) throws SQLException, Exception{
		service.deleteTask(taskID);
	}
	
	private String selfURI(UriInfo urinfo, Task task) {
		URI uri = urinfo.getBaseUriBuilder()
				.path(TaskResource.class)
				.path(Integer.toString(task.getTaskID()))
				.build();
		return uri.toString();
	}
	
	private String goalURI(UriInfo urinfo, Task task) {
		URI uri = urinfo.getBaseUriBuilder()
				.path(GoalResource.class)
				.path(task.getGoal())
				.build();
		return uri.toString();
	}

}
