﻿var rootURL = "http://localhost:8080/restful/webapi/users/";
var lastID;
var selectedUser;

//Select feltöltése adatbázisból:
$(document).ready(function(){
    $.ajax({
    	type: 'GET',
    	url: rootURL,
    	dataType: 'json',
    	contentType: "application/json",
    	success: function(data){
    		$.each(data, function(key, value){
    			var users = "<option value =" +  "\"" + value.userID + "\">";
    			users += value.userName; 
    			users += '</option>';
    			$("#userSelect").append(users);
    			lastID = value.userID;
    		});
    	}
    });
});

//Register new user:
var formData;
$("#createForm").change(function(){
	formData = {
	        "userID": (lastID +1),
			"userName" : $('#userName').val(),
	        "userEmail": $('#userEmail').val()
	    };
});

$("#submitCreate").click(function(){
	$.ajax({
		type: "POST",
		data: JSON.stringify(formData),
		url: rootURL,
		dataType: "json",
		contentType: "application/json",
		success: function(data){
			alert("New User added");
		}
	});
});

//Adott user adatainak listázása:
$("#selectForm").change(function(){
	selectedUser = $("#userSelect option:selected").val();
		$.ajax({
			type: "GET",
			data: selectedUser,
			url: rootURL + selectedUser,
			dataType: "json",
			contentType: "application/json",
			success: function(data){
				$.each(data, function(key, value){
					var user = '';
					user += '<td>' + value.userID + '</td>';
					user += '<td>' + value.userName + '</td>';
					user += '<td>' + value.userEmail + '</td>';
					$(user).appendTo("#responseTr");
				});
			},
			failure: function(){
				alert("Hiba");
			}
	});
});

//Adott user törlése:
$("#selectForm").change(function(){
	selectedUser = $("#userSelect option:selected").val();
	$("#deleteBtn").click(function(){
		$.ajax({
			type: "DELETE",
			data: selectedUser,
			url: rootURL + selectedUser,
			dataType: "json",
			contentType: "application/json",
			success: function(data){
				alert("Törlés sikeres");
			},
			failure: function(){
				alert("Hiba");
			}
		});
	});
});

//Response helye:
var $TABLE = $('#table');
var $BTN = $('#export-btn');
var $EXPORT = $('#export');

// A few jQuery helpers for exporting only
jQuery.fn.pop = [].pop;
jQuery.fn.shift = [].shift;

$BTN.click(function () {
  var $rows = $TABLE.find('tr:not(:hidden)');
  var headers = [];
  var data = [];
  
  // Get the headers (add special header logic here)
  $($rows.shift()).find('th:not(:empty)').each(function () {
    headers.push($(this).text().toLowerCase());
  });
  
  // Turn all existing rows into a loopable array
  $rows.each(function () {
    var $td = $(this).find('td');
    var h = {};
    
    // Use the headers from earlier to name our hash keys
    headers.forEach(function (header, i) {
      h[header] = $td.eq(i).text();   
    });
    
    data.push(h);
  });
  
  // Output the result
  $EXPORT.text(JSON.stringify(data));
});


//nav gombok:
$("#addGoalBtn").click(function(){
	//userID = getCookie(userCookieName);
	var goalsOnclick="goals.jsp?userID=" + $("#userSelect option:selected").val();
	window.location.