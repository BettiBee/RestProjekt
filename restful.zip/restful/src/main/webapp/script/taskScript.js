﻿$.urlParam = function(name){
    var results = new RegExp('[\?&]' + name + '=([^]*)').exec(window.location.href);
    if (results==null){
       return null;
    }
    else{
       return results[1] || 0;
    }
}
/*$.urlParam = function(name){
	var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
	return results[1] || 0;
}*/

// example.com?param1=name&param2=&id=6
var goalID = $.urlParam('goalID');
var goal = $.urlParam('goal');
var rootURL = "http://localhost:8080/restful/webapi/users/" + goalID + "/goals"; //ezt majd meg kell változtatni, ha már a Query paramétert beolvastuk meg a Path annotációkat átirtuk
var lastGoalID = 0;

//Select feltöltése adatbázisból:
$(document).ready(function(){
    $.ajax({
    	type: 'GET',
    	url: rootURL,
    	dataType: 'json',
    	success: function(data){
    		$.each(data, function(key, value){
    			var tasks = "<option value =" +  "\"" + value.taskID + "\">";
    			tasks += value.taskTitle; 
    			tasks += '</option>';
    			$("#taskSelect").append(tasks);
    			lastTaskID = value.taskID;
    		});
    	}, // lehet nem kell a zárójelben a data majd
    	error: function(jqXHR, textStatus, errorThrown){  
    	    alert("There was an error getting goals form the db/webservice.");  
    	    console.log(jqXHR);
    	    console.log(textStatus);
    	    console.log(errorThrown);
    	}  
    });
});

//Register new goal:
var formData;
$("#createTaskForm").change(function(){
	formData = {
	        "taskID": (lastTaskID +1),
			"taskTitle" : $('#taskTitle').val(),
	        "taskDate": $('#taskDate').val(),
	        "taskRepeat": $( "#taskRepeat option:selected" ).text(),
	        "goal": $.urlParam('goal'),
	        "goalID": $.urlParam('goalID')
	    };
});

$("#submitTaskCreate").click(function(){
	console.log(formData);
	$.ajax({
		type: "POST",
		data: JSON.stringify(formData),
		url: rootURL,
		dataType: "json",
		contentType: "application/json",
		success: function listDetails(data){
			alert(data);
		}
	});
});

//Adott goal adatainak listázása módositáshoz (selectben, név alapján választjuk ki a goalt):
var selectedtask;
var originalTaskName;

$("#selectTaskForm").change(function(){
	selectedtask = $("#taskSelect option:selected").val();
		$.ajax({
			type: "GET",
			data: selectedtask,
			url: rootURL + selectedtask,
			dataType: "json",
			success: function(data){
				$.each(data, function(key, value){
					originalTaskName = value.taskTitle;
					var task = '';
					task += '<td>' + value.taskID + '</td>';
					task += '<td>' + value.taskTitle + '</td>';
					task += '<td>' + value.taskDate + '</td>';
					task += '<td>' + value.taskRepeat + '</td>';
					task += '<td>' + value.goal + '</td>';
					$(task).appendTo("#responseTaskTr");
				});
			},
			failure: function(){
				alert("WTF???");
			}
	});
});

//Adott goal törlése: MŰKÖDIK BAZZMEG!!! :D
$("#selectTaskForm").change(function(){
	selectedtask = $("#taskSelect option:selected").val();
	$("#task-deleteBtn").click(function(){
		$.ajax({
			type: "DELETE",
			data: selectedtask,
			url: rootURL + selectedtask,
			dataType: "json",
			contentType: "text/plain",
			success: function listDetails(data){
				alert(data);
			},
			failure: function(){
				alert("WTF???");
			}
		});
	});
});

//Response helye:
var $TABLE = $('#taskTable');
var $BTN = $('#task-export-btn');
var $EXPORT = $('#task-export');

// A few jQuery helpers for exporting only
jQuery.fn.pop = [].pop;
jQuery.fn.shift = [].shift;

$BTN.click(function () {
  var $rows = $TABLE.find('tr:not(:hidden)');
  var headers = [];
  var data = [];
  
  // Get the headers (add special header logic here)
  $($rows.shift()).find('th:not(:empty)').each(function () {
    headers.push($(this).text().toLowerCase());
  });
  
  // Turn all existing rows into a loopable array
  $rows.each(function () {
    var $td = $(this).find('td');
    var h = {};
    
    // Use the headers from earlier to name our hash keys
    headers.forEach(function (header, i) {
      h[header] = $td.eq(i).text();   
    });
    
    data.push(h);
  });
  
  // Output the result
  $EXPORT.text(JSON.stringify(data));
});


//nav gombok:
$("#goBackToUser").click(function(){
	window.location.replace("index.jsp");
	
});
$("#goBackToGoal").click(function(){
	window.location.replace("goals.jsp");
	
});