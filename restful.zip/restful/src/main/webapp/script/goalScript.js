﻿//más lehetőségek queryparam elfogására:
//$('#city').val(decodeURIComponent($.urlParam('city'))); <-- valszeg ez csinálja a param-ot
/*$.urlParam = function(name){
    var results = new RegExp('[\?&]' + name + '=([^]*)').exec(window.location.href);
    if (results==null){
       return null;
    }
    else{
       return results[1] || 0;
    }
}*/
$.urlParam = function(name){
	var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
	return results[1] || 0;
}

// example.com?param1=name&param2=&id=6
var userID = $.urlParam('userID');
var rootURL = "http://localhost:8080/restful/webapi/users/" + userID + "/goals"; //ezt majd meg kell változtatni, ha már a Query paramétert beolvastuk meg a Path annotációkat átirtuk
var lastGoalID = 0;
var selectedgoal;

//Select feltöltése adatbázisból:
$(document).ready(function(){
    $.ajax({
    	type: 'GET',
    	url: rootURL,
    	dataType: 'json',
    	contentType: "application/json",
    	success: function(data){
    		$.each(data, function(key, value){
    			var goals = "<option value =" +  "\"" + value.goalID + "\">";
    			goals +=  value.goalTitle;
    			goals += '</option>';
    			$("#goalSelect").append(goals);
    			lastGoalID = value.goalID;
    		});
    	}
    });
});


//Register new goal:
var formData;
$("#createGoalForm").change(function(){
	formData = {
	        "goalID": (lastGoalID +1),
			"goalTitle" : $('#goalTitle').val(),
	        "goalDate": $('#goalDate').val(),
	        "goalStatus": $( "#goalStatusSelect option:selected" ).text(),
	        "user": $.urlParam('user'),
	        "userID": $.urlParam('userID')
	    };
});

$("#submitGoalCreate").click(function(){
	$.ajax({
		type: "POST",
		data: JSON.stringify(formData),
		url: rootURL,
		dataType: "json",
		contentType: "application/json",
		success: function listDetails(data){
			alert("Goal létrehozva");
		}
	});
});

//Adott goal adatainak listázása módositáshoz:

$("#selectGoalForm").change(function(){
	selectedgoal = $("#goalSelect option:selected").val();
		$.ajax({
			type: "GET",
			data: selectedgoal,
			url: rootURL + selectedgoal,
			dataType: "json",
			contentType: "application/json",
			success: function(data){
				var goal = '';
				goal += '<td>' + goalID + '</td>';
				goal += '<td>' + goalTitle + '</td>';
				goal += '<td>' + goalDate + '</td>';
				goal += '<td>' + goalStatus + '</td>';
				goal += '<td>' + user + '</td>';
				$(goal).appendTo("#responseGoalTr");
		},
		failure: function(){
			alert("Hiba");
		}
	});
});


//Adott goal törlése:
$("#selectGoalForm").change(function(){
	selectedgoal = $("#goalSelect option:selected").val();
	$("#Goal-deleteBtn").click(function(){
		$.ajax({
			type: "DELETE",
			data: selectedgoal,
			url: rootURL + selectedgoal,
			dataType: "json",
			contentType: "application/json",
			success: function listDetails(data){
				alert("Deleted");
			},
			failure: function(){
				alert("Error");
			}
		});
	});
});

//Response helye:
var $TABLE = $('#GoalTable');
var $BTN = $('#Goal-export-btn');
var $EXPORT = $('#Goalexport');

// A few jQuery helpers for exporting only
jQuery.fn.pop = [].pop;
jQuery.fn.shift = [].shift;

$BTN.click(function () {
  var $rows = $TABLE.find('tr:not(:hidden)');
  var headers = [];
  var data = [];
  
  // Get the headers (add special header logic here)
  $($rows.shift()).find('th:not(:empty)').each(function () {
    headers.push($(this).text().toLowerCase());
  });
  
  // Turn all existing rows into a loopable array
  $rows.each(function () {
    var $td = $(this).find('td');
    var h = {};
    
    // Use the headers from earlier to name our hash keys
    headers.forEach(function (header, i) {
      h[header] = $td.eq(i).text();   
    });
    
    data.push(h);
  });
  
  // Output the result
  $EXPORT.text(JSON.stringify(data));
});


//nav gombok:
$("#addTaskBtn").click(function(){
	//userID = getCookie(userCookieName);
	var tasksOnclick= "tasks.jsp?goalID=" + $("#goalSelect option:selected").val();
	window.location.replace(tasksOnclick);
	
});

$("#goBackToUser").click(function(){
	window.location.re